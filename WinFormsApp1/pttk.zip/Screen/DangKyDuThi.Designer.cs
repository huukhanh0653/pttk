﻿namespace WinFormsApp1
{
    partial class DangKyDuThi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DangKyDuThi));
            grBoxNguoiDKy = new GroupBox();
            panel5 = new Panel();
            textBoxEmailNgDKy = new TextBox();
            emailNguoiDKy = new Label();
            panel6 = new Panel();
            textBoxSDTNgDKy = new TextBox();
            SDTNguoiDKy = new Label();
            panel7 = new Panel();
            DTPNguoiDKy = new DateTimePicker();
            dobNguoiDKy = new Label();
            panel8 = new Panel();
            textBoxHoTenNguoiDKy = new TextBox();
            hoTenNguoiDKy = new Label();
            buttonDKy = new Button();
            button2 = new Button();
            grBoxNgThi = new GroupBox();
            panel4 = new Panel();
            textBoxEmailNgThi = new TextBox();
            emailNguoiThi = new Label();
            panel3 = new Panel();
            textBoxSDTNgThi = new TextBox();
            sdtNguoiThi = new Label();
            panel2 = new Panel();
            DTPNguoiThi = new DateTimePicker();
            dobNguoiThi = new Label();
            panel1 = new Panel();
            textBoxHoTenNgThi = new TextBox();
            hoTenNguoiThi = new Label();
            groupBox1 = new GroupBox();
            btnSearchKyThi = new Button();
            txtSearchKyThi = new TextBox();
            dgvDSKyThi = new DataGridView();
            groupBox2 = new GroupBox();
            btnSearchThiSinh = new Button();
            txtSearchThiSinh = new TextBox();
            dgvDSThiSinh = new DataGridView();
            lblTitle = new Label();
            btnReturn = new Button();
            btnSaveThiSinh = new Button();
            btnXoaThiSinh = new Button();
            btnXoaNguoiDangKy = new Button();
            grBoxNguoiDKy.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            grBoxNgThi.SuspendLayout();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDSKyThi).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDSThiSinh).BeginInit();
            SuspendLayout();
            // 
            // grBoxNguoiDKy
            // 
            grBoxNguoiDKy.BackgroundImageLayout = ImageLayout.Center;
            grBoxNguoiDKy.Controls.Add(panel5);
            grBoxNguoiDKy.Controls.Add(panel6);
            grBoxNguoiDKy.Controls.Add(panel7);
            grBoxNguoiDKy.Controls.Add(panel8);
            grBoxNguoiDKy.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grBoxNguoiDKy.Location = new Point(50, 65);
            grBoxNguoiDKy.Name = "grBoxNguoiDKy";
            grBoxNguoiDKy.Size = new Size(412, 202);
            grBoxNguoiDKy.TabIndex = 1;
            grBoxNguoiDKy.TabStop = false;
            grBoxNguoiDKy.Text = "Thông tin người đăng ký";
            // 
            // panel5
            // 
            panel5.Controls.Add(textBoxEmailNgDKy);
            panel5.Controls.Add(emailNguoiDKy);
            panel5.Location = new Point(6, 156);
            panel5.Name = "panel5";
            panel5.Size = new Size(398, 33);
            panel5.TabIndex = 4;
            // 
            // textBoxEmailNgDKy
            // 
            textBoxEmailNgDKy.ForeColor = Color.Black;
            textBoxEmailNgDKy.Location = new Point(89, 3);
            textBoxEmailNgDKy.Name = "textBoxEmailNgDKy";
            textBoxEmailNgDKy.Size = new Size(301, 25);
            textBoxEmailNgDKy.TabIndex = 1;
            // 
            // emailNguoiDKy
            // 
            emailNguoiDKy.AutoSize = true;
            emailNguoiDKy.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailNguoiDKy.Location = new Point(19, 6);
            emailNguoiDKy.Name = "emailNguoiDKy";
            emailNguoiDKy.Size = new Size(46, 17);
            emailNguoiDKy.TabIndex = 0;
            emailNguoiDKy.Text = "Email:";
            // 
            // panel6
            // 
            panel6.Controls.Add(textBoxSDTNgDKy);
            panel6.Controls.Add(SDTNguoiDKy);
            panel6.Location = new Point(6, 118);
            panel6.Name = "panel6";
            panel6.Size = new Size(398, 32);
            panel6.TabIndex = 3;
            // 
            // textBoxSDTNgDKy
            // 
            textBoxSDTNgDKy.ForeColor = Color.Black;
            textBoxSDTNgDKy.Location = new Point(119, 3);
            textBoxSDTNgDKy.Name = "textBoxSDTNgDKy";
            textBoxSDTNgDKy.Size = new Size(271, 25);
            textBoxSDTNgDKy.TabIndex = 1;
            // 
            // SDTNguoiDKy
            // 
            SDTNguoiDKy.AutoSize = true;
            SDTNguoiDKy.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SDTNguoiDKy.Location = new Point(19, 3);
            SDTNguoiDKy.Name = "SDTNguoiDKy";
            SDTNguoiDKy.Size = new Size(94, 17);
            SDTNguoiDKy.TabIndex = 0;
            SDTNguoiDKy.Text = "Số điện thoại:";
            // 
            // panel7
            // 
            panel7.Controls.Add(DTPNguoiDKy);
            panel7.Controls.Add(dobNguoiDKy);
            panel7.Location = new Point(6, 75);
            panel7.Name = "panel7";
            panel7.Size = new Size(398, 37);
            panel7.TabIndex = 2;
            // 
            // DTPNguoiDKy
            // 
            DTPNguoiDKy.CustomFormat = "dd/MM/yyyy";
            DTPNguoiDKy.Location = new Point(99, 6);
            DTPNguoiDKy.Name = "DTPNguoiDKy";
            DTPNguoiDKy.Size = new Size(291, 25);
            DTPNguoiDKy.TabIndex = 1;
            // 
            // dobNguoiDKy
            // 
            dobNguoiDKy.AutoSize = true;
            dobNguoiDKy.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dobNguoiDKy.Location = new Point(19, 12);
            dobNguoiDKy.Name = "dobNguoiDKy";
            dobNguoiDKy.Size = new Size(74, 17);
            dobNguoiDKy.TabIndex = 0;
            dobNguoiDKy.Text = "Ngày sinh:";
            // 
            // panel8
            // 
            panel8.Controls.Add(textBoxHoTenNguoiDKy);
            panel8.Controls.Add(hoTenNguoiDKy);
            panel8.Location = new Point(6, 31);
            panel8.Name = "panel8";
            panel8.Size = new Size(398, 35);
            panel8.TabIndex = 1;
            // 
            // textBoxHoTenNguoiDKy
            // 
            textBoxHoTenNguoiDKy.ForeColor = Color.Black;
            textBoxHoTenNguoiDKy.Location = new Point(89, 6);
            textBoxHoTenNguoiDKy.Name = "textBoxHoTenNguoiDKy";
            textBoxHoTenNguoiDKy.Size = new Size(301, 25);
            textBoxHoTenNguoiDKy.TabIndex = 1;
            // 
            // hoTenNguoiDKy
            // 
            hoTenNguoiDKy.AutoSize = true;
            hoTenNguoiDKy.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            hoTenNguoiDKy.Location = new Point(19, 9);
            hoTenNguoiDKy.Name = "hoTenNguoiDKy";
            hoTenNguoiDKy.Size = new Size(54, 17);
            hoTenNguoiDKy.TabIndex = 0;
            hoTenNguoiDKy.Text = "Họ tên:";
            // 
            // buttonDKy
            // 
            buttonDKy.BackColor = SystemColors.ActiveCaption;
            buttonDKy.Location = new Point(1415, 588);
            buttonDKy.Name = "buttonDKy";
            buttonDKy.Size = new Size(73, 36);
            buttonDKy.TabIndex = 3;
            buttonDKy.Text = "Đăng ký";
            buttonDKy.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaption;
            button2.Location = new Point(1297, 588);
            button2.Name = "button2";
            button2.Size = new Size(69, 36);
            button2.TabIndex = 5;
            button2.Text = "Thêm";
            button2.UseVisualStyleBackColor = false;
            // 
            // grBoxNgThi
            // 
            grBoxNgThi.BackgroundImageLayout = ImageLayout.Center;
            grBoxNgThi.Controls.Add(panel4);
            grBoxNgThi.Controls.Add(panel3);
            grBoxNgThi.Controls.Add(panel2);
            grBoxNgThi.Controls.Add(panel1);
            grBoxNgThi.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grBoxNgThi.Location = new Point(727, 65);
            grBoxNgThi.Name = "grBoxNgThi";
            grBoxNgThi.Size = new Size(420, 202);
            grBoxNgThi.TabIndex = 7;
            grBoxNgThi.TabStop = false;
            grBoxNgThi.Text = "Thông tin người thi";
            // 
            // panel4
            // 
            panel4.Controls.Add(textBoxEmailNgThi);
            panel4.Controls.Add(emailNguoiThi);
            panel4.Location = new Point(6, 157);
            panel4.Name = "panel4";
            panel4.Size = new Size(398, 32);
            panel4.TabIndex = 4;
            // 
            // textBoxEmailNgThi
            // 
            textBoxEmailNgThi.ForeColor = Color.Black;
            textBoxEmailNgThi.Location = new Point(89, 3);
            textBoxEmailNgThi.Name = "textBoxEmailNgThi";
            textBoxEmailNgThi.Size = new Size(301, 25);
            textBoxEmailNgThi.TabIndex = 1;
            // 
            // emailNguoiThi
            // 
            emailNguoiThi.AutoSize = true;
            emailNguoiThi.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailNguoiThi.Location = new Point(19, 6);
            emailNguoiThi.Name = "emailNguoiThi";
            emailNguoiThi.Size = new Size(46, 17);
            emailNguoiThi.TabIndex = 0;
            emailNguoiThi.Text = "Email:";
            // 
            // panel3
            // 
            panel3.Controls.Add(textBoxSDTNgThi);
            panel3.Controls.Add(sdtNguoiThi);
            panel3.Location = new Point(6, 118);
            panel3.Name = "panel3";
            panel3.Size = new Size(398, 33);
            panel3.TabIndex = 3;
            // 
            // textBoxSDTNgThi
            // 
            textBoxSDTNgThi.ForeColor = Color.Black;
            textBoxSDTNgThi.Location = new Point(119, 3);
            textBoxSDTNgThi.Name = "textBoxSDTNgThi";
            textBoxSDTNgThi.Size = new Size(271, 25);
            textBoxSDTNgThi.TabIndex = 1;
            // 
            // sdtNguoiThi
            // 
            sdtNguoiThi.AutoSize = true;
            sdtNguoiThi.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sdtNguoiThi.Location = new Point(19, 6);
            sdtNguoiThi.Name = "sdtNguoiThi";
            sdtNguoiThi.Size = new Size(94, 17);
            sdtNguoiThi.TabIndex = 0;
            sdtNguoiThi.Text = "Số điện thoại:";
            // 
            // panel2
            // 
            panel2.Controls.Add(DTPNguoiThi);
            panel2.Controls.Add(dobNguoiThi);
            panel2.Location = new Point(6, 72);
            panel2.Name = "panel2";
            panel2.Size = new Size(398, 40);
            panel2.TabIndex = 2;
            // 
            // DTPNguoiThi
            // 
            DTPNguoiThi.Location = new Point(99, 8);
            DTPNguoiThi.Name = "DTPNguoiThi";
            DTPNguoiThi.Size = new Size(291, 25);
            DTPNguoiThi.TabIndex = 1;
            // 
            // dobNguoiThi
            // 
            dobNguoiThi.AutoSize = true;
            dobNguoiThi.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dobNguoiThi.Location = new Point(19, 11);
            dobNguoiThi.Name = "dobNguoiThi";
            dobNguoiThi.Size = new Size(74, 17);
            dobNguoiThi.TabIndex = 0;
            dobNguoiThi.Text = "Ngày sinh:";
            // 
            // panel1
            // 
            panel1.Controls.Add(textBoxHoTenNgThi);
            panel1.Controls.Add(hoTenNguoiThi);
            panel1.Location = new Point(6, 28);
            panel1.Name = "panel1";
            panel1.Size = new Size(398, 34);
            panel1.TabIndex = 1;
            // 
            // textBoxHoTenNgThi
            // 
            textBoxHoTenNgThi.ForeColor = Color.Black;
            textBoxHoTenNgThi.Location = new Point(89, 3);
            textBoxHoTenNgThi.Name = "textBoxHoTenNgThi";
            textBoxHoTenNgThi.Size = new Size(301, 25);
            textBoxHoTenNgThi.TabIndex = 1;
            // 
            // hoTenNguoiThi
            // 
            hoTenNguoiThi.AutoSize = true;
            hoTenNguoiThi.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            hoTenNguoiThi.Location = new Point(19, 6);
            hoTenNguoiThi.Name = "hoTenNguoiThi";
            hoTenNguoiThi.Size = new Size(54, 17);
            hoTenNguoiThi.TabIndex = 0;
            hoTenNguoiThi.Text = "Họ tên:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnSearchKyThi);
            groupBox1.Controls.Add(txtSearchKyThi);
            groupBox1.Controls.Add(dgvDSKyThi);
            groupBox1.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(50, 308);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1097, 218);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Danh sách kỳ thi";
            // 
            // btnSearchKyThi
            // 
            btnSearchKyThi.BackgroundImage = Properties.Resources.search;
            btnSearchKyThi.BackgroundImageLayout = ImageLayout.Center;
            btnSearchKyThi.Location = new Point(1048, 11);
            btnSearchKyThi.Margin = new Padding(3, 2, 3, 2);
            btnSearchKyThi.Name = "btnSearchKyThi";
            btnSearchKyThi.Size = new Size(33, 31);
            btnSearchKyThi.TabIndex = 18;
            btnSearchKyThi.UseVisualStyleBackColor = true;
            // 
            // txtSearchKyThi
            // 
            txtSearchKyThi.ForeColor = Color.Black;
            txtSearchKyThi.Location = new Point(759, 15);
            txtSearchKyThi.Name = "txtSearchKyThi";
            txtSearchKyThi.Size = new Size(283, 25);
            txtSearchKyThi.TabIndex = 2;
            txtSearchKyThi.TextChanged += txtSearchKyThi_TextChanged;
            // 
            // dgvDSKyThi
            // 
            dgvDSKyThi.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDSKyThi.Location = new Point(12, 46);
            dgvDSKyThi.Name = "dgvDSKyThi";
            dgvDSKyThi.Size = new Size(1069, 166);
            dgvDSKyThi.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnSearchThiSinh);
            groupBox2.Controls.Add(txtSearchThiSinh);
            groupBox2.Controls.Add(dgvDSThiSinh);
            groupBox2.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(50, 532);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(1097, 226);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách thí sinh đăng ký";
            // 
            // btnSearchThiSinh
            // 
            btnSearchThiSinh.BackgroundImage = Properties.Resources.search;
            btnSearchThiSinh.BackgroundImageLayout = ImageLayout.Center;
            btnSearchThiSinh.Location = new Point(1048, 13);
            btnSearchThiSinh.Margin = new Padding(3, 2, 3, 2);
            btnSearchThiSinh.Name = "btnSearchThiSinh";
            btnSearchThiSinh.Size = new Size(33, 31);
            btnSearchThiSinh.TabIndex = 19;
            btnSearchThiSinh.UseVisualStyleBackColor = true;
            // 
            // txtSearchThiSinh
            // 
            txtSearchThiSinh.ForeColor = Color.Black;
            txtSearchThiSinh.Location = new Point(753, 17);
            txtSearchThiSinh.Name = "txtSearchThiSinh";
            txtSearchThiSinh.Size = new Size(283, 25);
            txtSearchThiSinh.TabIndex = 3;
            // 
            // dgvDSThiSinh
            // 
            dgvDSThiSinh.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDSThiSinh.Location = new Point(12, 49);
            dgvDSThiSinh.Name = "dgvDSThiSinh";
            dgvDSThiSinh.Size = new Size(1069, 171);
            dgvDSThiSinh.TabIndex = 0;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.Location = new Point(487, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(206, 37);
            lblTitle.TabIndex = 10;
            lblTitle.Text = "Đăng ký dự thi";
            lblTitle.Click += label1_Click_1;
            // 
            // btnReturn
            // 
            btnReturn.BackColor = Color.Transparent;
            btnReturn.BackgroundImage = (Image)resources.GetObject("btnReturn.BackgroundImage");
            btnReturn.BackgroundImageLayout = ImageLayout.Center;
            btnReturn.FlatStyle = FlatStyle.Flat;
            btnReturn.ForeColor = Color.Transparent;
            btnReturn.Location = new Point(50, 18);
            btnReturn.Margin = new Padding(3, 2, 3, 2);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(40, 31);
            btnReturn.TabIndex = 19;
            btnReturn.UseVisualStyleBackColor = false;
            btnReturn.Click += btnReturn_Click;
            // 
            // btnSaveThiSinh
            // 
            btnSaveThiSinh.BackColor = Color.Transparent;
            btnSaveThiSinh.BackgroundImageLayout = ImageLayout.Center;
            btnSaveThiSinh.ForeColor = Color.Black;
            btnSaveThiSinh.Location = new Point(1040, 272);
            btnSaveThiSinh.Margin = new Padding(3, 2, 3, 2);
            btnSaveThiSinh.Name = "btnSaveThiSinh";
            btnSaveThiSinh.Size = new Size(107, 31);
            btnSaveThiSinh.TabIndex = 20;
            btnSaveThiSinh.Text = "Thêm thí sinh";
            btnSaveThiSinh.UseVisualStyleBackColor = false;
            btnSaveThiSinh.Click += btnSaveThiSinh_Click;
            // 
            // btnXoaThiSinh
            // 
            btnXoaThiSinh.BackColor = Color.Transparent;
            btnXoaThiSinh.BackgroundImageLayout = ImageLayout.Center;
            btnXoaThiSinh.ForeColor = Color.Black;
            btnXoaThiSinh.Location = new Point(727, 272);
            btnXoaThiSinh.Margin = new Padding(3, 2, 3, 2);
            btnXoaThiSinh.Name = "btnXoaThiSinh";
            btnXoaThiSinh.Size = new Size(107, 31);
            btnXoaThiSinh.TabIndex = 21;
            btnXoaThiSinh.Text = "Xóa";
            btnXoaThiSinh.UseVisualStyleBackColor = false;
            btnXoaThiSinh.Click += btnXoaThiSinh_Click;
            // 
            // btnXoaNguoiDangKy
            // 
            btnXoaNguoiDangKy.BackColor = Color.Transparent;
            btnXoaNguoiDangKy.BackgroundImageLayout = ImageLayout.Center;
            btnXoaNguoiDangKy.ForeColor = Color.Black;
            btnXoaNguoiDangKy.Location = new Point(50, 272);
            btnXoaNguoiDangKy.Margin = new Padding(3, 2, 3, 2);
            btnXoaNguoiDangKy.Name = "btnXoaNguoiDangKy";
            btnXoaNguoiDangKy.Size = new Size(107, 31);
            btnXoaNguoiDangKy.TabIndex = 22;
            btnXoaNguoiDangKy.Text = "Xóa";
            btnXoaNguoiDangKy.UseVisualStyleBackColor = false;
            btnXoaNguoiDangKy.Click += btnXoaNguoiDangKy_Click;
            // 
            // DangKyDuThi
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnXoaNguoiDangKy);
            Controls.Add(btnXoaThiSinh);
            Controls.Add(btnSaveThiSinh);
            Controls.Add(btnReturn);
            Controls.Add(lblTitle);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(grBoxNgThi);
            Controls.Add(button2);
            Controls.Add(buttonDKy);
            Controls.Add(grBoxNguoiDKy);
            Cursor = Cursors.Hand;
            Name = "DangKyDuThi";
            Size = new Size(1184, 761);
            Load += MH_DKY_CA_NHAN_Load;
            grBoxNguoiDKy.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            grBoxNgThi.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDSKyThi).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDSThiSinh).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private GroupBox grBoxNguoiDKy;
        private Panel panel5;
        private TextBox textBoxEmailNgDKy;
        private Label emailNguoiDKy;
        private Panel panel6;
        private TextBox textBoxSDTNgDKy;
        private Label SDTNguoiDKy;
        private Panel panel7;
        private DateTimePicker DTPNguoiDKy;
        private Label dobNguoiDKy;
        private Panel panel8;
        private TextBox textBoxHoTenNguoiDKy;
        private Label hoTenNguoiDKy;
        private Button buttonDKy;
        private Button button2;
        private GroupBox grBoxNgThi;
        private Panel panel4;
        private TextBox textBoxEmailNgThi;
        private Label emailNguoiThi;
        private Panel panel3;
        private TextBox textBoxSDTNgThi;
        private Label sdtNguoiThi;
        private Panel panel2;
        private DateTimePicker DTPNguoiThi;
        private Label dobNguoiThi;
        private Panel panel1;
        private TextBox textBoxHoTenNgThi;
        private Label hoTenNguoiThi;
        private GroupBox groupBox1;
        private DataGridView dgvDSKyThi;
        private GroupBox groupBox2;
        private DataGridView dgvDSThiSinh;
        private TextBox txtSearchKyThi;
        private TextBox txtSearchThiSinh;
        private Label lblTitle;
        private Button btnSearchKyThi;
        private Button btnSearchThiSinh;
        private Button btnReturn;
        private Button btnSaveThiSinh;
        private Button btnXoaThiSinh;
        private Button btnXoaNguoiDangKy;

    }
}
