﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using WinFormsApp1.DAO;

namespace WinFormsApp1.Business
{
    internal class DanhSachChungChiBUS
    {
        private DanhSachChungChiDAO danhSachChungChiDAO = new DanhSachChungChiDAO();
        public DanhSachChungChiBUS() { }
        public DataTable GetAllDanhSachChungChi()
        {
            DataTable dataTable = danhSachChungChiDAO.getAllChungChi();
            return dataTable;
        }
        
        public DataRow getChungChiByMaChungChi(int maChungChi)
        {
            DataRow dataRow = danhSachChungChiDAO.getChungChiByMaChungChi(maChungChi);
            return dataRow;
        }

        public void CapPhatChungChi(int maChungChi)
        {

        }
    }
}
